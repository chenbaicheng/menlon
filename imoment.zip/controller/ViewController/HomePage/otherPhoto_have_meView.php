<?php
//这里不写入与数据库有关的代码
//***** 
//***** 
//*****
//***************


class otherPhoto_have_meView{

	public function __construct(){     .


	}
	public function otherPhoto_have_meView($otherPhoto_have_meViewModel){  //通过  viewModel 传入view
		// 接受一个对象数组   然后数组序列化生成json
		
	}
	
}

?>