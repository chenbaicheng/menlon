<?php
//这里不写入与数据库有关的代码
//***** 
//***** 
//*****
//***************


class userAllPhotoView{

	public function __construct(){     .


	}
	public function userAllPhotoView($userAllPhotoViewModel){  //通过  viewModel 传入view
		// 接受一个对象数组   然后数组序列化生成json
		
	}
	
}

?>